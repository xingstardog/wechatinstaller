-- beware this script is init script & have global influence on luastate
local _initModel = {}
-- do't use [key,val] table,lua kv table can't keep iterate order, we will use fileName as module name
_initModel.DebugBasePack = {
    {
        name="ltn12",
        path="Debug/ltn12.lua",
    },
    {
        name="socket",
        path="Debug/socket.lua",
    },
    {
        name="mime",
        path="Debug/mime.lua",
    },
    {
        name="mobdebug",
        path="Debug/mobdebug.lua",
    },
    {
        name="RciConst",
        path="Common/RciConst.lua",
    },
    {
        name="EffectConst",
        path="Common/EffectConst.lua",
    },
    {
        name="dkjson",
        path="Common/dkjson.lua"
    },
    {
        name="socket.url",
        path="Debug/url.lua",
    },
    {
        name="socket.headers",
        path="Debug/headers.lua"
    },
    {
        name="http",
        path="Debug/http.lua"
    }
}
_initModel.ReleaseBasePack = {
    {
        name="RciConst",
        path="Common/RciConst.lua",
    },
    {
        name="EffectConst",
        path="Common/EffectConst.lua",
    },
    {
        name="dkjson",
        path="Common/dkjson.lua"
    }
}


return _initModel